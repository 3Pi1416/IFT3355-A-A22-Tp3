# IFT3355-A-A22-TP3
Tp3 Infographie
Hugo Carrier 20197563
Maggie Robert 20182443 
Vanessa Thibault-Soucy 20126808